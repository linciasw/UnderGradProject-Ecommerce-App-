<style> 

        /************* GENERIC  ****************
    a {color:#696969;}*/



    h1 {
      text-align: center;
    }


    img {
    width: 100%;
    height: 50%;
    overflow: hidden;
    bottom: auto;
    }


    .twhite {color:#fff!important;}

    /************* TOP-HEAD *****************/

    .top-head ul li {padding-right:8px;}

    /****************** Navigation **************/
    .navbar-toggler {border-color: #dd0000;}



    /**************** Banner Slider Carousel **************/
   .carousel-inner img {
    width: 100%;
    overflow: hidden;
  } 


    .carousel-caption {color:#000; top:110px; bottom: auto; text-align:center;}

    .carousel-caption h1 {color:#000;top:50px; bottom: auto; text-align:center; } 

    /************ Services **************/
    .most-car-box:hover { box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);}
    /*********** TABS *******/
    .nav-tabs { border-bottom: 1px solid #ccc; }
    .nav-tabs .nav-link.active {
        border-bottom: 1px solid #dd0000;
        border-radius:0px;
    }



</style>





<!-- The slideshow 
 <div class="carousel-inner">-->
    <div class="img-fluid">
     <img class="img-fluid" src="Images/homepage.jpg" alt="Chicago"> 
      <div class="carousel-caption">
        <div class="col-md-12">
        <blockquote class="blockquote text-center">
            <h1 class="pb-2"><strong>Welcome to SiliconTT</strong> </h1>
            <h4 class="text-center">We guarantee you'll find what you're looking for</h4>
          </blockquote>
        </div>
      </div>   
    </div>






<!-- image that's working -->
<!-- https://images.cardekho.com/images/featuredcarimages/Maruti-Swift-17/Swift-new-0.jpg -->
<!-- dimensions for picture: 1686 * 548 -->






