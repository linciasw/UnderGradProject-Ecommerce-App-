<style>

    .container {
        margin-top: 25px;
        margin-bottom: 100px;
    }


    img {
    width: 100%;
    overflow: hidden;
    bottom: auto;
    }

</style>


<div class="container">


<div class="jumbotron">


<h1>Checkout was successful!</h1>
<p>Continue shopping <a href="<?php echo BASE_URL . "store"; ?>">here</a></p>




</div>

<!-- <img class="img-fluid" src="Images/cart.jpg" alt="Chicago">  -->
</div>