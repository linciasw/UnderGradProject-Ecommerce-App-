
<div class="container my-5">

<div class="jumbotron">

<hi>No products found  </hi>
<p> Search for something else    </p>
<p>
    Get back to store using the below link<a class="nav-link" href="<?php echo BASE_URL . "store"; ?>">Store</a>
</p>
</div>

</div>