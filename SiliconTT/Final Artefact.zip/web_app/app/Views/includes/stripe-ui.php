


<script src="https://polyfill.io/v3/polyfill.min.js?version=3.52.1&features=fetch"></script>
<script src="https://js.stripe.com/v3/"></script>





  <form action="checkout/stripe" method="POST">
    <button type="submit" class="btn btn-primary btn-lg btn-block" id="checkout-button">Checkout</button>
  </form>


      