<style>

    .container {
        margin-top: 25px;
        margin-bottom: 100px;
    }


    img {
    width: 100%;
    overflow: hidden;
    bottom: auto;
    }

</style>


<div class="container">


<div class="jumbotron">


<h1>Your cart is empty</h1>
<p>Continue shopping</p>




</div>

<!-- <img class="img-fluid" src="Images/cart.jpg" alt="Chicago">  -->
</div>